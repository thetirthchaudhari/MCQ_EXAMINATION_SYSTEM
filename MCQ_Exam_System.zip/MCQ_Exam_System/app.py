from flask import Flask, render_template, request, redirect, url_for, session, g
import sqlite3

app = Flask(__name__)
app.secret_key = 'tirth_mcq_secret_123'  # Secret key must be set BEFORE app.run

DATABASE = 'mcq_exam.db'

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        
        password = request.form['password']
        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT * FROM users WHERE email=? AND password=?", (email, password))
        user = cur.fetchone()
        if user:
            session['user'] = user[1]  # name
            session['role'] = user[4]  # role
            return redirect('/dashboard')
        else:
            return "Invalid credentials"
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
       
        password = request.form['password']
        conn = get_db()
        cur = conn.cursor()
        cur.execute("INSERT INTO users (name, email, password) VALUES (?, ?, ?)", (name, email, password))
        conn.commit()
        return redirect('/login')
    return render_template('register.html')

@app.route('/manage-questions')
def manage_questions():
    if 'user' in session and session['role'] == 'admin':
        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT * FROM questions")
        questions = cur.fetchall()
        return render_template("manage_questions.html", questions=questions)
    return redirect('/login')

@app.route('/delete-question/<int:id>')
def delete_question(id):
    if 'user' in session and session['role'] == 'admin':
        conn = get_db()
        cur = conn.cursor()
        cur.execute("DELETE FROM questions WHERE id=?", (id,))
        conn.commit()
        return redirect('/manage-questions')
    return redirect('/login')


@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/dashboard')
def dashboard():
    if 'user' in session:
        return render_template('dashboard.html', user=session['user'], role=session['role'])
    return redirect('/login')

@app.route('/take-test', methods=['GET', 'POST'])
def take_test():
    if 'user' in session and session['role'] == 'student':
        conn = get_db()
        cur = conn.cursor()

        if request.method == 'POST':
            score = 0
            total = 0

            cur.execute("SELECT id, correct_ans FROM questions")
            questions = cur.fetchall()
            total = len(questions)

            for q in questions:
                qid = str(q[0])
                correct = q[1]
                selected = request.form.get(qid)
                if selected == correct:
                    score += 1

            # Save result
            cur.execute("SELECT id FROM users WHERE name = ?", (session['user'],))
            user_id = cur.fetchone()[0]
            cur.execute("INSERT INTO results (user_id, score, total) VALUES (?, ?, ?)", (user_id, score, total))
            conn.commit()

            return render_template('result.html', score=score, total=total)

        # GET request — show questions
        cur.execute("SELECT * FROM questions")
        questions = cur.fetchall()
        return render_template('test.html', questions=questions)

    return redirect('/login')

@app.route('/add-question', methods=['GET', 'POST'])
def add_question():
    if 'user' in session and session['role'] == 'admin':
        if request.method == 'POST':
            question = request.form['question']
            opt1 = request.form['opt1']
            opt2 = request.form['opt2']
            opt3 = request.form['opt3']
            opt4 = request.form['opt4']
            correct = request.form['correct']
            conn = get_db()
            cur = conn.cursor()
            cur.execute("INSERT INTO questions (question, opt1, opt2, opt3, opt4, correct_ans) VALUES (?, ?, ?, ?, ?, ?)",
                        (question, opt1, opt2, opt3, opt4, correct))
            conn.commit()
            return redirect('/manage-questions')
        return render_template('add_question.html')
    return redirect('/login')

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

if __name__ == '__main__': 
    app.run(debug=True, port=5001)