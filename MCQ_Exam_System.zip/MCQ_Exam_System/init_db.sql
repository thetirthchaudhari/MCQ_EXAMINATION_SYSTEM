CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    
    name TEXT,
    email TEXT,
    password TEXT,
    role TEXT DEFAULT 'student'
    
);

CREATE TABLE questions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    question TEXT,
    opt1 TEXT,
    opt2 TEXT,
    opt3 TEXT,
    opt4 TEXT,
    correct_ans TEXT
);

CREATE TABLE results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
   
    score INTEGER,
    total INTEGER,
    taken_on DATETIME DEFAULT CURRENT_TIMESTAMP
);