import sqlite3

conn = sqlite3.connect('mcq_exam.db')
cur = conn.cursor()

cur.execute("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)",
            ('Tirth Chaudhari', 'tirth.chaudhari@icloud.com', '83088308', 'admin'))

conn.commit()
conn.close()

print("Admin user inserted ✅")